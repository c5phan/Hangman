/* 
Cindy Phan - Hangman Summative Program
Oei, ICS4U0

Class runs the overall game 
Allows user to choose if they want to start the game or not and also loops after each game has ended till the user chooses to quit*/

import java.util.*;

public class HangmanRunner {
    public static void main(String[] args) {
        HangmanPlayer start = new HangmanPlayer();
        System.out.println("Want to play Hangman? \nEnter \"start\" to begin and \"quit\" to exit!");
        Scanner in = new Scanner(System.in);  
        String choice = in.nextLine();
        String next = null;

        // loops till input entered is quit
        while (!choice.equalsIgnoreCase("quit")){
            try{
                // if user enter start, they are asked if they want the instructions
                if (choice.equalsIgnoreCase("start")){
                    System.out.println("\nWould you like the instructions? \nEnter \"yes\" or \"no\".");  
                    String option = in.nextLine();

                    // Loops till the answer is either yes or no, if yes, instructions are printed
                    while (!option.equalsIgnoreCase("no")){
                        try{
                            if (option.equalsIgnoreCase("yes")) {
                                System.out.println("\nHow to play: \nYou have 7 lives to guess the unknown word. \nGuess a letter each time and see if you're right or not!");                          
                                System.out.println("You can't guess punctuation, numbers or previously guessed letters. \nPress [Enter] to continue.");
                                next = in.nextLine();

                                // loops till user clicks enter
                                while (!next.equals("")){
                                    try{
                                        next = in.nextLine();
                                    }
                                    catch (Exception e){
                                        System.out.println("False input! Try again.");
                                    }
                                }
                                break;
                            }
                            else{
                                option = in.nextLine();
                            }
                        }
                        catch(Exception e){
                            System.out.println("False input! Try again.");
                        }
                    }

                    // Checks if user clicked enter or if they chose no for instructionsx
                    if (option.equalsIgnoreCase("no") || next.equals("")){
                        // Calls open (prints the menu) and play (starts each game) after the users chooses if they want instructions
                        start.open();
                        start.play();
                    }

                    // after game is over, everything resets and game loops
                    start.reset();
                    System.out.println("\nWant to play again? \nEnter \"start\" to begin and \"quit\" to exit!");
                    choice = in.nextLine();
                }
                // input is looped till it is either start or quit
                else {
                    choice = in.nextLine();
                }
            }
            catch(Exception e){
                System.out.println("False input! Try again.");  
            }
        }
        // Game closes if user enters quit
        if (choice.equalsIgnoreCase("quit")){
            System.out.println("\n> Goodbye... (ಥ ﹏ಥ )");
        }
    }
}
