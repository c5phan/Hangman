// Class is in charge for the actual gameplay

import java.util.*;

class HangmanPlayer extends HangmanStarter{
    private ArrayList<String> alphabet = new ArrayList<String>(); 
    private ArrayList<String> guessed = new ArrayList<String>(); //guessed letters
    private String[] blanks; // the dashes for the word (changes to letters if they guess it right)
    private String chosenWord;
    private String[][] image;
    private String prevLet; // previous wrong guess
    private static int lives = 7;
    private static int streak = 0; // winstreak count

    // Constructor assigns values to image and alphabet
    public HangmanPlayer(){
        image = super.getDefaultImage();
        String alphaAdd = "abcdefghijklmnopqrstuvwxyz";

        // loops till all letters are added to alphabet
        for (int i = 0; i < alphaAdd.length();i++){
            alphabet.add(alphaAdd.substring(i,i+1));
        }
    }

    // Method is in charge of running the game (Outputs images and text for each round and the final results)
    public void play(){
        chosenWord = super.getWord();
        blank(); //creates blank dashes

        //loop checks if they still have lives and if they've guessed the word
        while (lives > 0 && !(removeSpace(toString(blanks)).equalsIgnoreCase(chosenWord))){
            
            //clears screen 
            System.out.print("\033[H\033[2J");  
            System.out.flush();

            //outputs previous letter that was guessed and was wrong
            if (prevLet != null){
                System.out.println("\n" + prevLet + " is not in the word!");
            }

            super.imageOut(image);
            System.out.println("\nRemaining letters: " + alphabet);
            System.out.println("Guessed letters: " + guessed);
            System.out.println("Word: " + toString(blanks));

            //calls guess which allows for user to guess the letters
            guess();

        }

        //Results are outputted based on how many lives were left, win streak is outputted for both
        if (lives == 0){
            super.imageOut(image);
            streak = 0;
            System.out.println("\nYou failed to guess to word and lost! \nThe word was " + chosenWord + ".");
        }
        else{
            streak++;
            System.out.println("\n> Congrats you guessed the word! \nThe word was " + chosenWord + ".\n♪ ♬ ヾ(´︶`♡)ﾉ ♬ ♪");
        }
        System.out.println("Win streak: " + streak + "x");
    }

    // Method is in charge of each guess and the results whether if it's right or not
    public void guess(){
        System.out.println("\nGuess a letter: ");
        Scanner in = new Scanner(System.in);  
        String letter = in.nextLine();
        letter = letter.toLowerCase();

        // Checks if the guess is valid (1 letter, not a number/punctuation and hasn't been guessed before)
        if (letter.length() == 1 && !(check(letter))){

            //Checks if word contains letter
            if (chosenWord.indexOf(letter) >= 0){
                alphabet.remove(findLet(letter));
                guessed.add(letter);

                int index = chosenWord.indexOf(letter);
                int index2;
                String temp = chosenWord;
                
                // loops and replaces every dash that is the same index as the letter in the chosen word
                while (temp.indexOf(letter) >= 0){
                    blanks[index] = letter;
                    temp = chosenWord.substring(index+1);
                    index2 = temp.indexOf(letter);
                    if (index2 >= 0){
                        index += (index2+1);
                    }
                }
            }
            
            // If word doesn't contain the letter, a life is lost and other values are adjusted
            else{
                prevLet = letter;
                lives--;
                alphabet.remove(findLet(letter));
                guessed.add(letter);
                addBody();
            }
        }
    }

    // Method is in charge of adding part of the stickman if the guess is wrong
    // Based on the amount of lives left, a certian body part is added accordingly
    public void addBody(){
        if (lives >= 6){
            image[2][7]= "o";
        }
        if (lives == 5){
            image[3][6]= "/";
        }
        if (lives == 4){
            image[3][7]= "|";
        }
        if (lives == 3){
            image[3][8]= "\\";
        }
        if (lives == 2){
            image[4][7]= "|";
        }
        if (lives == 1){
            image[5][6]= "/";
        }
        if (lives == 0){
            image[5][8]= "\\";
        }
    }

    // Method creates blank spaces for each letter in the chosen word
    public void blank(){
        blanks = new String[chosenWord.length()];
        for (int i = 0; i < chosenWord.length();i++){
            blanks[i] = "_";
        }
    }

    // Method returns the index of the letter in alphabet arraylist
    public int findLet(String letter){
        int index = 0;
        for (int i = 0; i < alphabet.size(); i++){
            if (alphabet.get(i).equals(letter)){
                index = i;
            }
        }
        return index;
    }

    // Method changes an array to a string with spaces between each character and returns the string version
    public String toString(String[] arr){
        String temp = "";
        for (String let : arr){
            temp += let ;
            temp += " ";
        }
        return temp;
    }

    // Method removes the spaces from a string and returns the removed version
    public String removeSpace(String words){
        String removed = "";
        for (int i = 0; i < words.length();i++){
            if (!words.substring(i,i+1).equals(" ")){
                removed += words.substring(i,i+1);
            }
        }
        return removed;
    }

    // Method checks if letter was already guessed before or if it is a numerical value, returns true if so
    public boolean check(String let){
        // Checks if letter was guessed before, returns true if so
        for (String chara : guessed){
            if (chara.equals(let)){
                return true;
            }
        }

        // Checks if letter is a punctuation, returns true if so
        String[] punc = {"!", "@", "#", "$", "%", "^", "&", "*", "(", ")","-","_","+","=","`","~","<",",",".",">","?","/",";",":","'","{","}","[","]","|","\\","\""," "};
        for (String chara : punc){
            if (chara.equals(let)){
                return true;
            }
        }

        //Checks if letter is a number, returns true if so
        try{
            int val = Integer.parseInt(let);
            return true;
        }
        catch(NumberFormatException e){ 
        }
        
        // returns false otherwise
        return false;
    }

    // After each game, method is called to reset everything back to default values
    public void reset(){
        alphabet = new ArrayList<String>(); 
        guessed = new ArrayList<String>(); 

        // readds all the letters to the empty alphabet arraylist
        String alphaAdd = "abcdefghijklmnopqrstuvwxyz";
        for (int i = 0; i < alphaAdd.length();i++){
            alphabet.add(alphaAdd.substring(i,i+1));
        }
        lives = 7;
        prevLet = null; // original value was null

        // Resets image to just the stand
        image[2][7] = " ";
        image[3][6] = " ";
        image[3][7] = " ";
        image[3][8] = " ";
        image[4][7] = " ";
        image[5][6] = " ";
        image[5][8] = " ";
        
    }

}