// Class is in charge for the starting menu that's before the gameplay

import java.util.*;
import java.io.File;

class HangmanStarter{
    private String word;
    private String[][] defaultImage =   { {" ", " ", "-", "-", "-","-","-","-"," "," "," ",}, 
                                        {"\n ", " ", "|", " ", " "," "," ","|"," "," "," ",},
                                        {"\n ", " ", "|", " ", " "," "," "," "," "," "," ",},
                                        {"\n ", " ", "|", " ", " "," "," "," "," "," "," ",},
                                        {"\n ", " ", "|", " ", " "," "," "," "," "," "," ",},
                                        {"\n ", " ", "|", " ", " "," "," "," "," "," "," ",},
                                        {"\n ", " ", "|", " ", " "," "," "," "," "," "," ",},
                                        {"\n ", " ", "|", " ", " "," "," "," "," "," "," ",},
                                        {"\n-", "-", "-", "-", "-"," "," "," "," "," "," ",} };;
    
    // Method is in charge of opening after user chooses to play (banner and difficulty level outputted)
    public void start(){
        String[][] banner =  { {"=", "=", "=", "=", "=","=","=","=","=","=","=","=","=", "=", "=", "=","=","=","=","=","=", "=", "="}, 
                             {"\nH", "A", "N", "G", "M","A","N"," ","H","A","N","G", "M", "A", "N"," ","H","A","N","G", "M", "A", "N"},
                             {"\n=", "=", "=", "=", "=","=","=","=","=","=","=","=", "=", "=", "=","=","=","=","=","=", "=", "=", "="} };
        imageOut(banner);
        System.out.println("\n \nChoose your difficulty: \n    Food      - Enter 1 \n   Animals    - Enter 2 \n3 letter word - Enter 3 \n4 letter word - Enter 4\n5 letter word - Enter 5 \n");
    }


    // Method allows for user to choose level and based on choice, different text file is read and random word is chosen
    public void open(){      
        start();   
        int input = 0;
        Scanner level = new Scanner(System.in);  

        // loops till input is valid
        while (input < 1|| input > 5){
            try {
                System.out.println("Enter difficulty: ");
                input = Integer.parseInt(level.nextLine());

                // based on input, a specific text file is read
                if (input == 1){
                    this.word = randWord(textToString("food.txt"));
                }
                else if (input == 2){
                    this.word = randWord(textToString("animal.txt"));
                }
                else if (input == 3){
                    this.word = randWord(textToString("3word.txt"));
                }
                else if (input == 4){
                    this.word = randWord(textToString("4word.txt"));
                }
                else if (input == 5){
                    this.word = randWord(textToString("5word.txt"));
                }
                else {
                    System.out.println("Enter 1,2,3,4 or 5 only!");
                }
            }

            // If input is not valid, message is outputted
            catch(NumberFormatException e) {
                System.out.println("Enter 1,2,3,4 or 5 only!");
            }
        }
        
        // If input is valid, message outputted
        if (input >= 3 && input <= 5) {
            System.out.println("\nAn unknown word has been generated. \nTry to guess what it is!");
        }
    }

    // Method picks a random word from the String version of the text file
    public String randWord(String text){
        String word;

        /*Picks a random index in the text, takes the substring from that index to the end and adjusts the substring so it starts after the first space
          After having a adjusting the text, the first word is returned */
        int index = (int)(Math.random()*text.length()-1);
        text = text.substring(index);
        text = text.substring(text.indexOf(" ") + 1, text.length());
        if (text.indexOf(" ") >= 0){
            word = text.substring(0, text.indexOf(" "));
        }
        else{
            word = text;
        }
        return word;
    }


    // Method outputs the image (2d array)
    public void imageOut(String[][] arr){
        for (String row[] : arr){
            for (String col : row){
                System.out.print(col);
            }
        }
    }

    // Method converts the text file to string and returns the string
    public String textToString(String fileName){
        String words = "";
        try {
        Scanner text = new Scanner(new File(fileName));
            
            // loops till all the words in the file is added
            while(text.hasNext()){
                words += text.next() + " ";
            }
            text.close();
        }
        catch(Exception e){
            System.out.println(fileName + " not found");
        }
        return words;
    }
    
    // Method returns the chosen word
    public String getWord(){
        return this.word;
    }

    // Method returns the default image
    public String[][] getDefaultImage(){
        return defaultImage;
    }
}